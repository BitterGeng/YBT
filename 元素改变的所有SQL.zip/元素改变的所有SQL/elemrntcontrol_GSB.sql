


insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10q1', '', '', '', 1, '01', 'N/A', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10q2', '', '', '', 2, '01', 'N/A', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10q3', '', '', '', 3, '02', 'N/A', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10q4', '', '', '', 4, '02', 'N/A', '', '');

