insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice4', 'Y', '', '', 4, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice8i1', 'Y', '', '', 29, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice8i2', 'Y', '', '', 30, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice9', 'Y', '', '', 9, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice9a1', 'Y', '', '', 32, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice9i1', 'Y', '', '', 33, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice9i2', 'Y', '', '', 34, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10a1', 'Y', '', '', 34, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10', 'Y', '', '', 10, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10i1', 'Y', '', '', 35, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10i2', 'Y', '', '', 36, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice11', 'Y', '', '', 11, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice11a1', 'Y', '', '', 38, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice11i1', 'Y', '', '', 39, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice11i2', 'Y', '', '', 40, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice12', 'Y', '', '', 12, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice12a1', 'Y', '', '', 42, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice12i1', 'Y', '', '', 43, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice12i2', 'Y', '', '', 44, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice13', 'Y', '', '', 13, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice13a1', 'Y', '', '', 46, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice13i1', 'Y', '', '', 47, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice13i2', 'Y', '', '', 48, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice14', 'Y', '', '', 14, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice14a1', 'Y', '', '', 50, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice14i1', 'Y', '', '', 21, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice14i2', 'Y', '', '', 22, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice15', 'Y', '', '', 15, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice15a1', 'Y', '', '', 24, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice15i1', 'Y', '', '', 25, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice15i2', 'Y', '', '', 26, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice16', 'Y', '', '', 16, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice16a1', 'Y', '', '', 28, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice16i1', 'Y', '', '', 29, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice16i2', 'Y', '', '', 30, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice17', 'Y', '', '', 17, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice17a1', 'Y', '', '', 32, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice17i1', 'Y', '', '', 33, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice17i2', 'Y', '', '', 34, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice18', 'Y', '', '', 18, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice18a1', 'Y', '', '', 32, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice18i1', 'Y', '', '', 33, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice18i2', 'Y', '', '', 34, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice19', 'Y', '', '', 19, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice19a1', 'Y', '', '', 32, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice19i1', 'Y', '', '', 33, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice19i2', 'Y', '', '', 34, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice20', 'Y', '', '', 20, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice20a1', 'Y', '', '', 32, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice20i1', 'Y', '', '', 33, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice20i2', 'Y', '', '', 34, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice21', 'Y', '', '', 21, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice21a1', 'Y', '', '', 32, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice21i1', 'Y', '', '', 33, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice21i2', 'Y', '', '', 34, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice22', 'Y', '', '', 22, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice22a1', 'Y', '', '', 36, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice22i1', 'Y', '', '', 37, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice22i2', 'Y', '', '', 38, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice23', 'Y', '', '', 23, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice23a1', 'Y', '', '', 40, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice23i1', 'Y', '', '', 41, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice23i2', 'Y', '', '', 42, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24', 'Y', '', '', 27, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24a1', 'Y', '', '', 61, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24i1', 'Y', '', '', 62, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24i2', 'Y', '', '', 63, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice25', 'Y', '', '', 25, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice25a1', 'Y', '', '', 48, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice25i1', 'Y', '', '', 49, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice25i2', 'Y', '', '', 50, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice26', 'Y', '', '', 26, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice26a1', 'Y', '', '', 52, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice26i1', 'Y', '', '', 53, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice26i2', 'Y', '', '', 54, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q1', 'Y', '', '', 65, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q2', 'Y', '', '', 66, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q3', 'Y', '', '', 67, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q4', 'Y', '', '', 68, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q5', 'Y', '', '', 69, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice27', 'Y', '', '', 27, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice27a1', 'Y', '', '', 72, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice27i1', 'Y', '', '', 73, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice27i2', 'Y', '', '', 74, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice28', 'Y', '', '', 58, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice28a1', 'Y', '', '', 106, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice28i1', 'Y', '', '', 107, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice28i2', 'Y', '', '', 108, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice29', 'Y', '', '', 59, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice29a1', 'Y', '', '', 110, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice29i1', 'Y', '', '', 111, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice29i2', 'Y', '', '', 112, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice30', 'Y', '', '', 60, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice30a1', 'Y', '', '', 114, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice30i1', 'Y', '', '', 115, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice30i2', 'Y', '', '', 116, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice31', 'Y', '', '', 61, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice31a1', 'Y', '', '', 118, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice31i1', 'Y', '', '', 119, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice31i2', 'Y', '', '', 120, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice32', 'Y', '', '', 62, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice32a1', 'Y', '', '', 122, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice32i1', 'Y', '', '', 123, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice32i2', 'Y', '', '', 124, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice33', 'Y', '', '', 63, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice34', 'Y', '', '', 134, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice35', 'Y', '', '', 135, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice33i2', 'Y', '', '', 131, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice33i1', 'Y', '', '', 130, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice33a1', 'Y', '', '', 129, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice36', 'Y', '', '', 36, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice36a1', 'Y', '', '', 20, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice36i1', 'Y', '', '', 21, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice36i2', 'Y', '', '', 22, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice37', 'Y', '', '', 37, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice37a1', 'Y', '', '', 24, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice37i1', 'Y', '', '', 25, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice37i2', 'Y', '', '', 26, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice38', 'Y', '', '', 38, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice38a1', 'Y', '', '', 28, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice38i1', 'Y', '', '', 29, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice38i2', 'Y', '', '', 30, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice39', 'Y', '', '', 39, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice39a1', 'Y', '', '', 32, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice39i1', 'Y', '', '', 33, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice39i2', 'Y', '', '', 34, '01', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice2i1', 'Y', '', '', 5, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice2a1', 'Y', '', '', 4, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice2', 'Y', '', '', 2, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice1q2', 'Y', '', '', 2, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice1q1', 'Y', '', '', 1, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice1', 'Y', '', '', 1, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice2i2', 'Y', '', '', 6, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice3i2', 'Y', '', '', 10, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice3i1', 'Y', '', '', 9, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice3a1', 'Y', '', '', 8, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice3', 'Y', '', '', 3, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice8a1', 'Y', '', '', 28, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice8', 'Y', '', '', 8, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice7i2', 'Y', '', '', 26, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice7i1', 'Y', '', '', 25, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice7a1', 'Y', '', '', 24, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice7', 'Y', '', '', 7, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice6i2', 'Y', '', '', 22, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice6i1', 'Y', '', '', 21, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice6a1', 'Y', '', '', 20, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice6', 'Y', '', '', 6, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice5i2', 'Y', '', '', 18, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice5i1', 'Y', '', '', 17, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice5a1', 'Y', '', '', 16, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice5', 'Y', '', '', 5, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice4i2', 'Y', '', '', 14, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice4i1', 'Y', '', '', 13, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice4a1', 'Y', '', '', 12, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice4', 'Y', '', '', 4, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice8i1', 'Y', '', '', 29, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice8i2', 'Y', '', '', 30, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice9', 'Y', '', '', 9, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice9a1', 'Y', '', '', 32, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice9i1', 'Y', '', '', 33, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice9i2', 'Y', '', '', 34, '01', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10a1', 'Y', '', '', 34, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10', 'Y', '', '', 10, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10i1', 'Y', '', '', 35, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice10i2', 'Y', '', '', 36, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice11', 'Y', '', '', 11, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice11a1', 'Y', '', '', 38, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice11i1', 'Y', '', '', 39, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice11i2', 'Y', '', '', 40, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice12', 'Y', '', '', 12, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice12a1', 'Y', '', '', 42, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice12i1', 'Y', '', '', 43, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice12i2', 'Y', '', '', 44, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice13', 'Y', '', '', 13, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice13a1', 'Y', '', '', 46, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice13i1', 'Y', '', '', 47, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice13i2', 'Y', '', '', 48, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice14', 'Y', '', '', 14, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice14a1', 'Y', '', '', 50, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice14i1', 'Y', '', '', 21, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice14i2', 'Y', '', '', 22, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice15', 'Y', '', '', 15, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice15a1', 'Y', '', '', 24, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice15i1', 'Y', '', '', 25, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice15i2', 'Y', '', '', 26, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice16', 'Y', '', '', 16, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice16a1', 'Y', '', '', 28, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice16i1', 'Y', '', '', 29, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice16i2', 'Y', '', '', 30, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice17', 'Y', '', '', 17, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice17a1', 'Y', '', '', 32, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice17i1', 'Y', '', '', 33, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice17i2', 'Y', '', '', 34, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice18', 'Y', '', '', 18, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice18a1', 'Y', '', '', 32, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice18i1', 'Y', '', '', 33, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice18i2', 'Y', '', '', 34, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice19', 'Y', '', '', 19, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice19a1', 'Y', '', '', 32, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice19i1', 'Y', '', '', 33, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice19i2', 'Y', '', '', 34, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice20', 'Y', '', '', 20, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice20a1', 'Y', '', '', 32, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice20i1', 'Y', '', '', 33, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice20i2', 'Y', '', '', 34, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice21', 'Y', '', '', 21, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice21a1', 'Y', '', '', 32, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice21i1', 'Y', '', '', 33, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice21i2', 'Y', '', '', 34, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice22', 'Y', '', '', 22, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice22a1', 'Y', '', '', 36, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice22i1', 'Y', '', '', 37, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice22i2', 'Y', '', '', 38, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice23', 'Y', '', '', 23, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice23a1', 'Y', '', '', 40, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice23i1', 'Y', '', '', 41, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice23i2', 'Y', '', '', 42, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24', 'Y', '', '', 27, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24a1', 'Y', '', '', 61, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24i1', 'Y', '', '', 62, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24i2', 'Y', '', '', 63, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice25', 'Y', '', '', 25, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice25a1', 'Y', '', '', 48, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice25i1', 'Y', '', '', 49, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice25i2', 'Y', '', '', 50, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice26', 'Y', '', '', 26, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice26a1', 'Y', '', '', 52, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice26i1', 'Y', '', '', 53, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice26i2', 'Y', '', '', 54, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q1', 'Y', '', '', 65, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q2', 'Y', '', '', 66, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q3', 'Y', '', '', 67, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q4', 'Y', '', '', 68, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice24q5', 'Y', '', '', 69, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice27', 'Y', '', '', 27, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice27a1', 'Y', '', '', 72, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice27i1', 'Y', '', '', 73, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice27i2', 'Y', '', '', 74, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice28', 'Y', '', '', 58, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice28a1', 'Y', '', '', 106, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice28i1', 'Y', '', '', 107, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice28i2', 'Y', '', '', 108, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice29', 'Y', '', '', 59, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice29a1', 'Y', '', '', 110, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice29i1', 'Y', '', '', 111, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice29i2', 'Y', '', '', 112, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice30', 'Y', '', '', 60, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice30a1', 'Y', '', '', 114, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice30i1', 'Y', '', '', 115, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice30i2', 'Y', '', '', 116, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice31', 'Y', '', '', 61, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice31a1', 'Y', '', '', 118, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice31i1', 'Y', '', '', 119, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice31i2', 'Y', '', '', 120, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice32', 'Y', '', '', 62, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice32a1', 'Y', '', '', 122, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice32i1', 'Y', '', '', 123, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice32i2', 'Y', '', '', 124, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice33', 'Y', '', '', 63, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice34', 'Y', '', '', 134, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice35', 'Y', '', '', 135, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice33i2', 'Y', '', '', 131, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice33i1', 'Y', '', '', 130, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice33a1', 'Y', '', '', 129, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice36', 'Y', '', '', 36, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice36a1', 'Y', '', '', 20, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice36i1', 'Y', '', '', 21, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice36i2', 'Y', '', '', 22, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice37', 'Y', '', '', 37, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice37a1', 'Y', '', '', 24, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice37i1', 'Y', '', '', 25, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice37i2', 'Y', '', '', 26, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice38', 'Y', '', '', 38, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice38a1', 'Y', '', '', 28, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice38i1', 'Y', '', '', 29, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice38i2', 'Y', '', '', 30, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice39', 'Y', '', '', 39, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice39a1', 'Y', '', '', 32, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice39i1', 'Y', '', '', 33, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice39i2', 'Y', '', '', 34, '', 'simpleNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice2i1', 'Y', '', '', 5, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice2a1', 'Y', '', '', 4, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice2', 'Y', '', '', 2, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice1q2', 'Y', '', '', 2, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice1q1', 'Y', '', '', 1, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice1', 'Y', '', '', 1, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice2i2', 'Y', '', '', 6, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice3i2', 'Y', '', '', 10, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice3i1', 'Y', '', '', 9, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice3a1', 'Y', '', '', 8, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice3', 'Y', '', '', 3, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice8a1', 'Y', '', '', 28, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice8', 'Y', '', '', 8, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice7i2', 'Y', '', '', 26, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice7i1', 'Y', '', '', 25, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice7a1', 'Y', '', '', 24, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice7', 'Y', '', '', 7, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice6i2', 'Y', '', '', 22, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice6i1', 'Y', '', '', 21, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice6a1', 'Y', '', '', 20, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice6', 'Y', '', '', 6, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice5i2', 'Y', '', '', 18, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice5i1', 'Y', '', '', 17, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice5a1', 'Y', '', '', 16, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice5', 'Y', '', '', 5, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice4i2', 'Y', '', '', 14, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice4i1', 'Y', '', '', 13, '', 'complexNotice', '', '');

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnotice', 'notice4a1', 'Y', '', '', 12, '', 'complexNotice', '', '');

