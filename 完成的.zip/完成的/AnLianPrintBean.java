package com.sinosoft.service.business.ui.contprint.bean;

/**
 *
 * @author Admin
 * @date： 日期：2018年3月16日 时间：下午2:31:31
 * @version 1.0
 */
public class AnLianPrintBean {

	/**
	 * 第一被保人
	 */

	// 姓名
	private String insFullName;

	// 性別
	private String insMale;
	private String insFemale;

	// 出生日期
	private String insBirthday;

	// 年龄
	private String insAge;

	// 证件类型
	private String insIDType;

	// 证件号码
	private String insIDNum;

	// 证件有效期
	private String insIDExpiry;

	// 国籍
	private String insState;

	// 出生地所属国籍
	private String insBirthState;

	// 是否医保参保
	private String insYes1;

	private String insNo1;

	// 个人年收入
	private String insAnnIncome;

	// 行业类型
	private String insDuty;

	// 具体工作
	private String insDetailWork;

	// 工作单位
	private String insCompany;

	// 邮编
	private String insPostalCode;

	// 手机号码
	private String insMobile;

	// 居住地址
	private String insContactAddress;

	// 固定电话
	private String insTelephone;

	// 邮箱
	private String insEmail;

	/**
	 * 第二被保人
	 */
	// 姓名
	private String insFullName1;

	// 性別
	private String insMale1;
	private String insFemale1;

	// 出生日期
	private String insBirthday1;

	// 年龄
	private String insAge1;

	// 与第一被保人的关系
	private String insRelation;

	// 证件类型
	private String insIDType1;

	// 证件号码
	private String insIDNum1;

	// 证件有效期
	private String insIDExpiry1;

	// 国籍
	private String insState1;

	// 出生地所属国籍
	private String insBirthState1;

	// 是否医保参保
	private String insYes2;

	private String insNo2;

	// 个人年收入
	private String insAnnIncome1;

	// 行业类型
	private String insDuty1;

	// 具体工作
	private String insDetailWork1;

	// 工作单位
	private String insCompany1;

	// 邮编
	private String insPostalCode1;

	// 手机号码
	private String insMobile1;

	// 居住地址
	private String insContactAddress1;

	// 固定电话
	private String insTelephone1;

	// 邮箱
	private String insEmail1;

	/**
	 * 投保人
	 */

	// 投保人姓名
	private String appFullName;

	// 性别
	private String appMale;
	private String appFemale;

	// 投保人出生日期
	private String appBirthday;

	// 年龄
	private String appAge;

	// 证件类型
	private String appIDType;

	// 证件号码
	private String appIDNum;

	// 证件有效期
	private String appIDExpiry;

	// 国籍
	private String appState;

	// 出生国家
	private String appBirthState;

	// 与第一被保人关系
	private String appRelation;

	// 个人年收入
	private String appAnnIncome;

	// 工作单位
	private String appCompany;

	// 行业类型
	private String appDuty;

	// 具体工作
	private String appDetailWork;

	// 居住地址
	private String appContactAddress;

	// 邮编
	private String appPostalCode;

	// 电话号码
	private String appTelephone;

	// 邮箱
	private String appEmail;

	// 手机号码
	private String appMobile;

	/**
	 * 身故受益人
	 */

	/** 第一被保险人身故受益人 */
	// 姓名
	private String benefitName1;

	// 出生日期
	private String dateOfBirth1;

	// 性别
	private String gender1;

	// 证件类型
	private String idType1;

	// 证件号码
	private String benefitIdNo1;

	// 与第一被保险人关系
	private String relation1;

	// 受益率
	private String byShare1;

	private String benefitName2;

	private String dateOfBirth2;

	private String gender2;

	private String idType2;

	private String benefitIdNo2;

	private String relation2;

	private String byShare2;

	/** 第二被保险人身故受益人 */
	private String benefitName3;

	private String dateOfBirth3;

	private String gender3;

	private String idType3;

	private String benefitIdNo3;

	private String relation3;

	private String byShare3;

	private String benefitName4;

	private String dateOfBirth4;

	private String gender4;

	private String idType4;

	private String benefitIdNo4;

	private String relation4;

	private String byShare4;

	/** 两被保险人同时身故情况下的受益人 */
	private String benefitName5;

	private String dateOfBirth5;

	private String gender5;

	private String idType5;

	private String benefitIdNo5;

	private String relation5;

	private String byShare5;

	private String benefitName6;

	private String dateOfBirth6;

	private String gender6;

	private String idType6;

	private String benefitIdNo6;

	private String relation6;

	private String byShare6;

	/**
	 * 投保计划险种
	 */

	/** 主险 */

	// 主险名称
	private String mainRiskName;

	// 基本保额
	private String mianSumInsured;

	// 类型
	private String mainSaType;

	// 保险期间
	private String benefitTerm;

	// 保险费支付期
	private String premiumTerm;

	// 期交/趸交保险费
	private String rsPremium;

	// 首期追加保险费
	private String firstAppendPrem;

	/** 附加险 */

	/** 第一被保险人附加险 */

	// 险种名称
	private String additonRiskName1;
	private String additonRiskName2;
	private String additonRiskName3;
	private String additonRiskName4;
	private String additonRiskName5;
	private String additonRiskName6;

	// 基本保险金额
	private String additonSumInsured1;
	private String additonSumInsured2;
	private String additonSumInsured3;
	private String additonSumInsured4;
	private String additonSumInsured5;
	private String additonSumInsured6;

	// 类型
	private String additonSaType1;
	private String additonSaType2;
	private String additonSaType3;
	private String additonSaType4;
	private String additonSaType5;
	private String additonSaType6;

	// 保险期间
	private String addbenefitTerm1;
	private String addbenefitTerm2;
	private String addbenefitTerm3;
	private String addbenefitTerm4;
	private String addbenefitTerm5;
	private String addbenefitTerm6;

	// 保险费支付期
	private String addPremiumTerm1;
	private String addPremiumTerm2;
	private String addPremiumTerm3;
	private String addPremiumTerm4;
	private String addPremiumTerm5;
	private String addPremiumTerm6;

	// 保险费
	private String addPrem1;
	private String addPrem2;
	private String addPrem3;
	private String addPrem4;
	private String addPrem5;
	private String addPrem6;

	/** 第二被保险人附加险 */

	// 险种名称
	private String sAdditonRiskName1;
	private String sAdditonRiskName2;
	private String sAdditonRiskName3;
	private String sAdditonRiskName4;
	private String sAdditonRiskName5;
	private String sAdditonRiskName6;

	// 基本保险金额
	private String sAdditonSumInsured1;
	private String sAdditonSumInsured2;
	private String sAdditonSumInsured3;
	private String sAdditonSumInsured4;
	private String sAdditonSumInsured5;
	private String sAdditonSumInsured6;

	// 类型
	private String sAdditonSaType1;
	private String sAdditonSaType2;
	private String sAdditonSaType3;
	private String sAdditonSaType4;
	private String sAdditonSaType5;
	private String sAdditonSaType6;

	// 保险期间
	private String sAddbenefitTerm1;
	private String sAddbenefitTerm2;
	private String sAddbenefitTerm3;
	private String sAddbenefitTerm4;
	private String sAddbenefitTerm5;
	private String sAddbenefitTerm6;

	// 保险费支付期
	private String sAddPremiumTerm1;
	private String sAddPremiumTerm2;
	private String sAddPremiumTerm3;
	private String sAddPremiumTerm4;
	private String sAddPremiumTerm5;
	private String sAddPremiumTerm6;

	// 保险费
	private String sAddPrem1;
	private String sAddPrem2;
	private String sAddPrem3;
	private String sAddPrem4;
	private String sAddPrem5;
	private String sAddPrem6;

	/** 红利领取方式 */
	// 累计生息
	private String cashAccumulation;

	// 抵交保费
	private String premiumDeduction;

	// 现金领取
	private String cashPay;

	// 其他
	private String othersDividend;

	// 具体红利名称
	private String othersDividendName;

	/** 年金领取方式 */
	// 月领领取
	private String monthly;

	// 年度领取
	private String annually;

	// 累积生息
	private String accumulatedAZ;

	// 其他领取方式
	private String otherAnnuity;

	// 其他具体名称
	private String otherAnnuityName;

	// 起始年金领取年龄
	private String vestingAge;

	// 年金领取年限
	private String vestingYear;

	/** 交费方式 */
	// 一次交清
	private String paySingle;

	// 年交
	private String payAnnually;

	// 半年交
	private String biAnnually;

	// 季度交
	private String payQuarterly;

	// 月交
	private String payMonthly;

	/** 交费方法 */
	// 自动转账
	private String transmatic;

	// 现金
	private String cash;

	// 支票
	private String cheque;

	// 一年期主险是否自动申请续保
	private String yes3;

	private String no3;

	// 申请适用优选体费率
	private String aqf;

	// 保险费自动垫交选择
	private String apl;

	// 首期保险费
	private String totalPremium;

	// 授权银行
	private String nameBank;

	// 授权银行分行机构
	private String nameBranchBank;

	// 开户地
	private String accountArea;

	// 省份
	private String nameBankProvince;

	// 城市
	private String nameBankCity;

	/** 年金 */
	private String nameBankIns;

	private String nameBranchBankIns;

	private String accountAreaIns;

	private String nameBankProvinceIns;

	private String nameBankCityIns;

	// 授权账户号码
	private String accountNumber1;
	private String accountNumber2;
	private String accountNumber3;
	private String accountNumber4;
	private String accountNumber5;
	private String accountNumber6;
	private String accountNumber7;
	private String accountNumber8;
	private String accountNumber9;
	private String accountNumber10;
	private String accountNumber11;
	private String accountNumber12;
	private String accountNumber13;
	private String accountNumber14;
	private String accountNumber15;
	private String accountNumber16;
	private String accountNumber17;
	private String accountNumber18;
	private String accountNumber19;
	private String accountNumber20;

	// 投资产品
	private String investAcc1;
	private String investAcc2;
	private String investAcc3;
	private String investAcc4;
	private String investAcc5;
	private String investAcc6;
	private String investAcc7;

	// 分配比例
	private String proportion1;
	private String proportion2;
	private String proportion3;
	private String proportion4;
	private String proportion5;
	private String proportion6;
	private String proportion7;

	// 投资账户自动转换
	private String investmentAccAut;

	// 保单生效后立即进行投资
	private String immediately;

	// 保单犹豫期满后进行投资
	private String cooling;

	/**
	 * 简单告知
	 */
	// 身高
	private String simpleHeight;

	// 体重
	private String simpleWeight;

	// 1
	private String impartYes1;
	private String impartNo1;

	// 2
	private String impartYes2;
	private String impartNo2;

	// 3
	private String impartYes3;
	private String impartNo3;

	// 4
	private String impartYes4;
	private String impartNo4;

	// 5
	private String impartYes5;
	private String impartNo5;

	// 6
	private String impartYes6;
	private String impartNo6;

	// 7
	private String impartYes7;
	private String impartNo7;

	private String impartYes7a;
	private String impartNo7a;

	/** 健康告知回答是的内容 */

	// 序号
	private String number1;
	private String number2;
	private String number3;
	private String number4;
	private String number5;

	// 说明对象
	private String who1;
	private String who2;
	private String who3;
	private String who4;
	private String who5;

	// 日期
	private String date1;
	private String date2;
	private String date3;
	private String date4;
	private String date5;

	// 原因
	private String reason1;
	private String reason2;
	private String reason3;
	private String reason4;
	private String reason5;

	// 就诊医院
	private String hospital1;
	private String hospital2;
	private String hospital3;
	private String hospital4;
	private String hospital5;

	// 接受的检查和治疗
	private String examTreatment1;
	private String examTreatment2;
	private String examTreatment3;
	private String examTreatment4;
	private String examTreatment5;

	// 诊断
	private String diagnosis1;
	private String diagnosis2;
	private String diagnosis3;
	private String diagnosis4;
	private String diagnosis5;

	// 最近一次治疗
	private String timeTreatment1;
	private String timeTreatment2;
	private String timeTreatment3;
	private String timeTreatment4;
	private String timeTreatment5;

	// 目前状况
	private String currentStatus1;
	private String currentStatus2;
	private String currentStatus3;
	private String currentStatus4;
	private String currentStatus5;

	/**
	 * 复杂产品告知
	 */

	// 身高
	private String complexHeight;

	// 体重
	private String complexWeight;

	/*** 第一部分告知 */
	// 1
	private String comImpartYes1;
	private String comImpartNo1;

	// 2
	private String comImpartYes2;
	private String comImpartNo2;

	// 3
	private String comImpartYes3;
	private String comImpartNo3;

	// 4
	private String comImpartYes4;
	private String comImpartNo4;

	// 5
	private String comImpartYes5;
	private String comImpartNo5;

	// 6
	private String comImpartYes6;
	private String comImpartNo6;

	// 7
	private String comImpartYes7;
	private String comImpartNo7;

	// 8
	private String comImpartYes8;
	private String comImpartNo8;

	// 9
	private String comImpartYes9;
	private String comImpartNo9;

	// 10
	private String comImpartYes10;
	private String comImpartNo10;

	// 11
	private String comImpartYes11;
	private String comImpartNo11;

	/*** 第二部分告知 */

	// 1
	private String sComImpartYes1;
	private String sComImpartNo1;

	// 2
	private String sComImpartYes2;
	private String sComImpartNo2;

	/*** 第三部分告知 */
	private String thComImpartYes1;
	private String thComImpartNo1;

	/*** 第四部分告知 */
	// 1
	private String fComImpartYes1;
	private String fComImpartNo1;

	// 2
	private String fComImpartYes2;
	private String fComImpartNo2;
	// 年
	private String drinkYear;

	// 种类
	private String drinkKind;

	// 饮酒次数
	private String drinkTime;

	// 喝多少两
	private String drinkLiang;

	// 毫升
	private String drinkML;

	// 3
	private String fComImpartYes3;
	private String fComImpartNo3;

	/*** 第五部分告知 */
	private String fvComImpartYes1;
	private String fvComImpartNo1;

	/*** 第六部分告知 */
	// 1
	private String sxComImpartYes1;
	private String sxComImpartNo1;

	// 2
	private String sxComImpartYes2;
	private String sxComImpartNo2;

	// 3
	private String sxComImpartYes3;
	private String sxComImpartNo3;

	/*** 第七部分告知 */
	// 1
	private String sevComImpartYes1;
	private String sevComImpartNo1;

	// 2
	private String sevComImpartYes2;
	private String sevComImpartNo2;

	/*** 第八部分告知 */
	// 1
	private String ehtComImpartYes1;
	private String ehtComImpartNo1;

	/*** 第九部分告知 */
	private String nineComImpartYes1;
	private String nineComImpartNo1;

	/*** 第十部分告知 */
	private String tenComImpartYes1;
	private String tenComImpartNo1;

	/*** 第十一部分告知 */
	private String eleComImpartYes1;
	private String eleComImpartNo1;

	
	
	/**健康告知内容中回答“是”，请注明对象（投保人、被保险人）*/
	// 序号
	private String comNumber1;
	private String comNumber2;
	private String comNumber3;
	private String comNumber4;
	private String comNumber5;

	// 说明对象
	private String comWho1;
	private String comWho2;
	private String comWho3;
	private String comWho4;
	private String comWho5;

	// 日期
	private String comDate1;
	private String comDate2;
	private String comDate3;
	private String comDate4;
	private String comDate5;

	// 原因
	private String comReason1;
	private String comReason2;
	private String comReason3;
	private String comReason4;
	private String comReason5;

	// 就诊医院
	private String comHospital1;
	private String comHospital2;
	private String comHospital3;
	private String comHospital4;
	private String comHospital5;

	// 接受的检查和治疗
	private String comExamTreatment1;
	private String comExamTreatment2;
	private String comExamTreatment3;
	private String comExamTreatment4;
	private String comExamTreatment5;

	// 诊断
	private String comDiagnosis1;
	private String comDiagnosis2;
	private String comDiagnosis3;
	private String comDiagnosis4;
	private String comDiagnosis5;

	// 最近一次治疗
	private String comTimeTreatment1;
	private String comTimeTreatment2;
	private String comTimeTreatment3;
	private String comTimeTreatment4;
	private String comTimeTreatment5;

	// 目前状况
	private String comCurrentStatus1;
	private String comCurrentStatus2;
	private String comCurrentStatus3;
	private String comCurrentStatus4;
	private String comCurrentStatus5;
	
	
	/**其它告知为内容中回答“是”，请注明对象（投保人、被保险人）*/
	//
	private String otherComNumber1;
	private String otherComNumber2;
	
	private String otherComWho1;
	private String otherComWho2;
	
	private String otherComDate1;
	private String otherComDate2;
	
	private String otherComReason1;
	private String otherComReason2;
	
	private String otherComHospital1;
	private String otherComHospital2;

	private String otherComExamTreatment1;
	private String otherComExamTreatment2;
	
	private String  otherComDiagnosis1;
	private String  otherComDiagnosis2;
	
	private String  otherComTimeTreatment1;
	private String  otherComTimeTreatment2;
	
	private String  otherComCurrentStatus1;
	private String  otherComCurrentStatus2;
	
	
	
	/**
	 * 税收部分
	 */
	//仅中国
	private String onlyCN;
	
	//非中国税收居民
	private String onlyNL;
	
	//既是中国税收居民，又是其他税收管辖区居民
	private String bothArea;
	
	//税收居民地区
	private String taxArea;
	
	//税收识别号
	private String taxNo;
	
	//不发放识别号
	private String noTaxNo;
	
	//未能取得识别号
	private  String notHave;
	
	//原因
	private String taxReason;
	
	
	//是否有美国绿卡
	private String isUsaCard;
	
	private  String noUsaCard;
	
	//是否有双重国籍
	private String isDualNation;
	
	private String noDualNation;
	
	
	
	/**
	 * 机构签名代号
	 */
	//代理销售机构  
	private String branchCode;
	
	
	//银行经办人员
	private String branchPeopleName;
	
	
	//安联营销人员
	private  String saleName;
	
	//地点
	private  String salePlace;
	
	
	
	
	
	
	
	
	
	
	
	
	
}
