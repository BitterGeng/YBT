var tab_d = $('#cusTable');

// 页面初始化
$(document).ready(function() {
	
	/** 加载页面表格 */
	var col = [{
		checkbox:true
	},{
		field : 'id',
		title : '序号',
		formatter : function(value, row, index) {
			return index + 1;
		}
	}, {
		field : 'proposalcontno',
		title : '投保单号',
		align : 'center',
		valign : 'middle',
	}, {
		field : 'appntname',
		title : '投保人姓名',
		align : 'center',
		valign : 'middle'
	}, {
		field : 'insuranceName',
		title : '保险公司名称',
		align : 'center',
		valign : 'middle'
	}, {
		field : 'comName',
		title : '银行机构名称',
		align : 'center',
		valign : 'middle'
	}, {
		field : 'emplid',
		title : '客户经理',
		align : 'center',
		valign : 'middle'
	}, {
		field : 'docName',
		title : '投保单',
		align : 'center',
		valign : 'middle'
	}, {
		title : '操作',
		align : 'center',
		formatter : actionFormatter,
		events : actionEvents
	}];

	var uniqueId = "metentid";
	$("#search").click(function() {
		$("#upload").removeAttr("disabled");
		$("#download").removeAttr("disabled"); 
		$("#cusTable").bootstrapTable('destroy');
		url_d = "/contUploadController/select.do";
		tableInit3(url_d, tab_d, col, uniqueId, queryParams);
	});
	
	
	$("#upload").click(function(){
		var data= tab_d.bootstrapTable('getSelections'); 
		if(data.length==1){
//			alert(data[0].proposalcontno);
			$("#contNoValue").val(data[0].proposalcontno);
			$("#bankcode").val(data[0].comcode);
			$("#insuranceCom").val(data[0].agentCode);
			$("#myForm").submit();
		}else if(data.length==0){
			alert("请选择一条要上传的保单!");
			return;
		}else{
			alert("只能选择一条保单数据上传!");
			return;
		}

	});
});


function queryParams(params) {
	// 设置查询参数
	var param = {
		limit : params.limit,
		offset : params.offset,
		contNo: $("#contNo").val().trim(),
		tBRBirth: $("#tBRBirth").val().trim(),
	};
	return param;
};


function tableInit3(url, obj, col, uniqueId, queryParams) {
	obj.bootstrapTable({
		url : path + url, // 请求后台的URL（*）
		dataType : "json",
		method : 'post', // 请求方式（*）
		contentType : "application/x-www-form-urlencoded",
		toolbar : '#toolbar',
		columns : col,
		striped : true, // 是否显示行间隔色
		cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		pagination : true, // 是否显示分页（*）
		queryParamsType : "limit",// undefined/limit
		queryParams : queryParams,// 传递参数（*）
		sidePagination : "server", // 分页方式：client客户端分页，server服务端分页（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		strictSearch : false,// 设置为 true启用 全匹配搜索，否则为模糊搜索
		showColumns : false, // 是否显示所有的列
//		showRefresh : true, // 是否显示刷新按钮
		minimumCountColumns : 2, // 最少允许的列数
		clickToSelect : true, // 是否启用点击选中行
		uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
		showToggle : false, // 是否显示详细视图和列表视图的切换按钮
		cardView : false, // 是否显示详细视图
		detailView : false// 是否显示父子表
	});
};


function actionFormatter(value, row, index) {
	if(row.path=='' || row.path==null){
		return;
	}
	return [ '<button class="btn btn-primary download">下载</button>' ].join('');
};

window.actionEvents = {
		
		'click .download' : function(e, value, row, index) {
			
			$.ajax({
				url:path + "/contUploadController/download.do",// 后台请求URL地址
				type : "POST",
				data : {"path":row.path,"docName":row.docName},
				success : function(data) {
					if(data.success==true){
						var url = "download.jsp?name="+encodeURI(encodeURI(data.parm));
						window.location.href=url;
					}else{
						alert(data.msg);
					}
				},
				error : function() {
					alert("下载失败!");
				}
			});
		}
		
};