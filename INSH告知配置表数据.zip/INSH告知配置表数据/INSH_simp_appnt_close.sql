insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice1', '', '', '', 1, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice1q1', '', '', '', 2, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice1q2', '', '', '', 3, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2', '', '', '', 3, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2i1', '', '', '', 4, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2q1', '', '', '', 5, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2q2', '', '', '', 6, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2q3', '', '', '', 7, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice5', '', '', '', 8, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice6i1', '', '', '', 9, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice6', '', '', '', 10, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice6a1', '', '', '', 11, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice7', '', '', '', 12, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice7i1', '', '', '', 13, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice7a1', '', '', '', 14, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice8', '', '', '', 15, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice8i1', '', '', '', 16, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice8a1', '', '', '', 17, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice9', '', '', '', 18, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice9i1', '', '', '', 19, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice9a1', '', '', '', 20, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice10', '', '', '', 21, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice10i1', '', '', '', 22, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice10a1', '', '', '', 23, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice11', '', '', '', 24, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice11i1', '', '', '', 25, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice11a1', '', '', '', 26, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice12', '', '', '', 27, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice12i1', '', '', '', 28, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice12a1', '', '', '', 29, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice13', '', '', '', 30, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice13i1', '', '', '', 31, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice13a1', '', '', '', 32, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice14', '', '', '', 33, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice14i1', '', '', '', 34, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice14a1', '', '', '', 35, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice15', '', '', '', 36, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice15i1', '', '', '', 37, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice15a1', '', '', '', 38, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice16', '', '', '', 39, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice16i1', '', '', '', 40, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice16a1', '', '', '', 41, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice17', '', '', '', 42, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice17i1', '', '', '', 43, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice17a1', '', '', '', 44, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice18', '', '', '', 45, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice18i1', '', '', '', 46, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice18a1', '', '', '', 47, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21', '', '', '', 47, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21i1', '', '', '', 48, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21q1', '', '', '', 49, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21q2', '', '', '', 50, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21q3', '', '', '', 51, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21q4', '', '', '', 52, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22', '', '', '', 53, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22i1', '', '', '', 54, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q1', '', '', '', 55, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q2', '', '', '', 56, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q3', '', '', '', 57, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q4', '', '', '', 58, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q5', '', '', '', 59, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q6', '', '', '', 60, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice23', '', '', '', 62, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice23i1', '', '', '', 63, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice23a1', '', '', '', 64, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice24', '', '', '', 65, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice24i1', '', '', '', 66, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice24a1', '', '', '', 67, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice25', '', '', '', 68, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice25i1', '', '', '', 69, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice25a1', '', '', '', 70, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice26', '', '', '', 71, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice26i1', '', '', '', 72, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice26a1', '', '', '', 73, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice27', '', '', '', 74, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice27i1', '', '', '', 75, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice27a1', '', '', '', 76, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice28', '', '', '', 77, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice28q1', '', '', '', 78, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice28i1', '', '', '', 79, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice28a1', '', '', '', 80, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice29', '', '', '', 81, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice29i1', '', '', '', 82, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice29a1', '', '', '', 83, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice30', '', '', '', 84, '02', 'INSH_simp_app_close', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice30q1', '', '', '', 85, '02', 'INSH_simp_app_close', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice30q2', '', '', '', 86, '02', 'INSH_simp_app_close', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice30i1', '', '', '', 87, '02', 'INSH_simp_app_close', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice31', '', '', '', 88, '02', 'INSH_simp_app_close', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice31i1', '', '', '', 89, '02', 'INSH_simp_app_close', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice31a1', '', '', '', 90, '02', 'INSH_simp_app_close', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice32', '', '', '', 91, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice32q1', '', '', '', 92, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice32q2', '', '', '', 93, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice32q3', '', '', '', 94, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice33', '', '', '', 95, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice33i1', '', '', '', 96, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice33q1', '', '', '', 96, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice33q2', '', '', '', 97, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice34', '', '', '', 98, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice34i1', '', '', '', 99, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice34a1', '', '', '', 100, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice35', '', '', '', 101, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice35i1', '', '', '', 102, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice35a1', '', '', '', 103, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice36', '', '', '', 104, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice36i1', '', '', '', 105, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice36a1', '', '', '', 106, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice37', '', '', '', 107, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice37i1', '', '', '', 108, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice37a1', '', '', '', 109, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice38', '', '', '', 110, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice38i1', '', '', '', 111, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice38a1', '', '', '', 112, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice39', '', '', '', 113, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice39a1', '', '', '', 114, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40', '', '', '', 115, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40i1', '', '', '', 116, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40a1', '', '', '', 117, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40q1', '', '', '', 119, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40q2', '', '', '', 120, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40q3', '', '', '', 121, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice41', '', '', '', 124, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice41i1', '', '', '', 125, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice41a1', '', '', '', 126, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice42', '', '', '', 127, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice42i1', '', '', '', 128, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice42a1', '', '', '', 129, '02', 'INSH_simp_app_close', '', '');



insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice43', '', '', '', 130, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice43q1', '', '', '', 131, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice43q2', '', '', '', 132, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice43q3', '', '', '', 133, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice44', '', '', '', 135, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice44i1', '', '', '', 136, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice45', '', '', '', 137, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice45i1', '', '', '', 138, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice46', '', '', '', 139, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice46i1', '', '', '', 140, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice47', '', '', '', 141, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice47i1', '', '', '', 142, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice48', '', '', '', 143, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice48a1', '', '', '', 144, '02', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice49', '', '', '', 145, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice50', '', '', '', 146, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice50q1', '', '', '', 147, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice51', '', '', '', 148, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice51q1', '', '', '', 149, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice52', '', '', '', 150, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice52q1', '', '', '', 151, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice54', '', '', '', 156, '01', 'INSH_simp_app_close', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice54q1', '', '', '', 157, '01', 'INSH_simp_app_close', '', 'textarea_notice');

