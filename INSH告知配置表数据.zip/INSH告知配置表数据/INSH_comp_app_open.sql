insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice1', '', '', '', 1, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice1q1', '', '', '', 2, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice1q2', '', '', '', 3, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2', '', '', '', 3, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2i1', '', '', '', 4, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2q1', '', '', '', 5, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2q2', '', '', '', 6, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice2q3', '', '', '', 7, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice5', '', '', '', 8, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice6i1', '', '', '', 9, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice6', '', '', '', 10, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice6a1', '', '', '', 11, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice7', '', '', '', 12, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice7i1', '', '', '', 13, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice7a1', '', '', '', 14, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice8', '', '', '', 15, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice8i1', '', '', '', 16, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice8a1', '', '', '', 17, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice9', '', '', '', 18, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice9i1', '', '', '', 19, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice9a1', '', '', '', 20, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice10', '', '', '', 21, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice10i1', '', '', '', 22, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice10a1', '', '', '', 23, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice11', '', '', '', 24, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice11i1', '', '', '', 25, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice11a1', '', '', '', 26, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice12', '', '', '', 27, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice12i1', '', '', '', 28, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice12a1', '', '', '', 29, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice13', '', '', '', 30, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice13i1', '', '', '', 31, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice13a1', '', '', '', 32, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice14', '', '', '', 33, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice14i1', '', '', '', 34, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice14a1', '', '', '', 35, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice15', '', '', '', 36, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice15i1', '', '', '', 37, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice15a1', '', '', '', 38, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice16', '', '', '', 39, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice16i1', '', '', '', 40, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice16a1', '', '', '', 41, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice17', '', '', '', 42, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice17i1', '', '', '', 43, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice17a1', '', '', '', 44, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice18', '', '', '', 45, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice18i1', '', '', '', 46, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice18a1', '', '', '', 47, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21', '', '', '', 47, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21i1', '', '', '', 48, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21q1', '', '', '', 49, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21q2', '', '', '', 50, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21q3', '', '', '', 51, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice21q4', '', '', '', 52, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22', '', '', '', 53, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22i1', '', '', '', 54, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q1', '', '', '', 55, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q2', '', '', '', 56, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q3', '', '', '', 57, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q4', '', '', '', 58, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q5', '', '', '', 59, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice22q6', '', '', '', 60, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice23', '', '', '', 62, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice23i1', '', '', '', 63, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice23a1', '', '', '', 64, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice24', '', '', '', 65, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice24i1', '', '', '', 66, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice24a1', '', '', '', 67, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice25', '', '', '', 68, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice25i1', '', '', '', 69, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice25a1', '', '', '', 70, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice26', '', '', '', 71, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice26i1', '', '', '', 72, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice26a1', '', '', '', 73, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice27', '', '', '', 74, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice27i1', '', '', '', 75, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice27a1', '', '', '', 76, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice28', '', '', '', 77, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice28q1', '', '', '', 78, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice28i1', '', '', '', 79, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice28a1', '', '', '', 80, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice29', '', '', '', 81, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice29i1', '', '', '', 82, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice29a1', '', '', '', 83, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice30', '', '', '', 84, '01', 'INSH_comp_app_open', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice30q1', '', '', '', 85, '01', 'INSH_comp_app_open', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice30q2', '', '', '', 86, '01', 'INSH_comp_app_open', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice30i1', '', '', '', 87, '01', 'INSH_comp_app_open', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice31', '', '', '', 88, '01', 'INSH_comp_app_open', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice31i1', '', '', '', 89, '01', 'INSH_comp_app_open', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice31a1', '', '', '', 90, '01', 'INSH_comp_app_open', 'infant', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice32', '', '', '', 91, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice32q1', '', '', '', 92, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice32q2', '', '', '', 93, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice32q3', '', '', '', 94, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice33', '', '', '', 95, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice33i1', '', '', '', 96, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice33q1', '', '', '', 96, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice33q2', '', '', '', 97, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice34', '', '', '', 98, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice34i1', '', '', '', 99, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice34a1', '', '', '', 100, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice35', '', '', '', 101, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice35i1', '', '', '', 102, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice35a1', '', '', '', 103, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice36', '', '', '', 104, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice36i1', '', '', '', 105, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice36a1', '', '', '', 106, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice37', '', '', '', 107, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice37i1', '', '', '', 108, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice37a1', '', '', '', 109, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice38', '', '', '', 110, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice38i1', '', '', '', 111, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice38a1', '', '', '', 112, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice39', '', '', '', 113, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice39a1', '', '', '', 114, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40', '', '', '', 115, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40i1', '', '', '', 116, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40a1', '', '', '', 117, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40q1', '', '', '', 119, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40q2', '', '', '', 120, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice40q3', '', '', '', 121, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice41', '', '', '', 124, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice41i1', '', '', '', 125, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice41a1', '', '', '', 126, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice42', '', '', '', 127, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice42i1', '', '', '', 128, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice42a1', '', '', '', 129, '01', 'INSH_comp_app_open', '', '');



insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice43', '', '', '', 130, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice43q1', '', '', '', 131, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice43q2', '', '', '', 132, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice43q3', '', '', '', 133, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice44', '', '', '', 135, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice44i1', '', '', '', 136, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice45', '', '', '', 137, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice45i1', '', '', '', 138, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice46', '', '', '', 139, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice46i1', '', '', '', 140, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice47', '', '', '', 141, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice47i1', '', '', '', 142, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice48', '', '', '', 143, '02', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice48a1', '', '', '', 144, '02', 'INSH_comp_app_open', '', '');



insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice49', '', '', '', 145, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice50', '', '', '', 146, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice50q1', '', '', '', 147, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice51', '', '', '', 148, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice51q1', '', '', '', 149, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice52', '', '', '', 150, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice52q1', '', '', '', 151, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice54', '', '', '', 156, '01', 'INSH_comp_app_open', '', '');

insert into Elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('INSHnotice', 'notice54q1', '', '', '', 157, '01', 'INSH_comp_app_open', '', 'textarea_notice');

