prompt Importing table elementsofcontrol...
set feedback off
set define off
insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailNo', null, null, null, null, '01', 'N/A', null, null);

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailWho', null, null, null, null, '01', 'N/A', null, null);

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailDate', null, null, null, null, '01', 'N/A', null, null);

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailReason', null, null, null, null, '01', 'N/A', null, null);

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailHospital', null, null, null, null, '01', 'N/A', null, null);

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailTreat', null, null, null, null, '01', 'N/A', null, null);

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailDiagnosis', null, null, null, null, '01', 'N/A', null, null);

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailLastTreatData', null, null, null, null, '01', 'N/A', null, null);

insert into elementsofcontrol (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('ANZLnoticedetail', 'noticedetailCurrent', null, null, null, null, '01', 'N/A', null, null);

prompt Done.
