alter table SIMPLENOTICEINFO modify transno VARCHAR2(32);
alter table SIMPLENOTICEINFO modify impartcode VARCHAR2(32);
alter table SIMPLENOTICEINFO add noticetype VARCHAR2(16);
alter table SIMPLENOTICEINFO
  add constraint SIMPLENOTICEINFO_PK primary key (TRANSNO, IMPARTCODE, NOTICETYPE);