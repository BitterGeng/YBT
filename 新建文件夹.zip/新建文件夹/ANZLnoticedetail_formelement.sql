prompt Importing table formelement...
set feedback off
set define off
insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailNo', 'noticeinfo1', '���', 'text', null, null, 'noticedetails', null, null);

insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailWho', 'noticeinfo2', '˵������', 'text', null, null, 'noticedetails', null, null);

insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailDate', 'noticeinfo3', '����', 'text', null, null, 'noticedetails', null, null);

insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailReason', 'noticeinfo4', 'ԭ��', 'text', null, null, 'noticedetails', null, null);

insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailHospital', 'noticeinfo5', '����ҽԺ', 'text', null, null, 'noticedetails', null, null);

insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailTreat', 'noticeinfo6', '���ܵļ�������', 'text', null, null, 'noticedetails', null, null);

insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailDiagnosis', 'noticeinfo7', '���', 'text', null, null, 'noticedetails', null, null);

insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailLastTreatData', 'noticeinfo8', '���һ������ʱ��', 'text', null, null, 'noticedetails', null, null);

insert into formelement (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('ANZLnoticedetail', 'noticedetailCurrent', 'noticeinfo9', 'Ŀǰ״��', 'text', null, null, 'noticedetails', null, null);

prompt Done.
commit;